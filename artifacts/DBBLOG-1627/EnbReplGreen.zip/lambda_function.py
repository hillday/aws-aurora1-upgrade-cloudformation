import json
import boto3
import traceback
import logging
import pymysql
import sys
import os
import pprint

#lambda_client = boto3.client('lambda')

def lambda_handler(event, context):
    #This assumes the destination cluster has been created & This lambda will fire once the Writer is Created to start Binlog replication from Master(Blue) to Green Cluster
    #1. Load the MySQL Username & Password to connect Aurora
    #2. The function will create its own Username & password for replication (repl_user) Password will be a randomly generated password
    #3. Connect to the Destination Cluster & Set Read ONLY mode to true
    #4... Follow the rest of the process
    print('################### Event ######################')
    print(event)
   
    
    #Connect to Cluster/Writer endpoint to enable replication
    rds_Host  = event.get('writer_Endpoint_Address')
    rds_Port = event.get('writer_Endpoint_Port')
    mysql_username = event.get('mysql_master_user').get('username')
    mysql_password = event.get('mysql_master_user').get('password')
    replication_username = event.get('mysql_replication_user').get('username')
    replication_password = event.get('mysql_replication_user').get('password')
    binlog_File = event.get('binlog_File')
    binlog_Position = event.get('binlog_Position')
    replication_Source = event.get('blue_Cluster_Writer_Endpoint')
    
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    
    try:
        print('Trying to connect to MySQL')
        conn = pymysql.connect(rds_Host, user=mysql_username, passwd=mysql_password, connect_timeout=5, autocommit = True)
    
    except pymysql.MySQLError as e:
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        traceback.print_exc()
    
    logger.info("SUCCESS: Connection to RDS MySQL instance succeeded")
    item_count = 0
    
    with conn.cursor() as cur:
        print('Starting Binlog Replication from Blue Cluster')
        #Conifgure MySQL replication by using mysql.rds_set_external_master.
        mysql_replication_comamnd = 'call mysql.rds_set_external_master (\''+replication_Source+'\', 3306, \''+replication_username+'\', \''+replication_password+'\' , \''+binlog_File+'\', '+str(binlog_Position)+', 0)'
        cur.execute(mysql_replication_comamnd)
        #Start Replication
        cur.execute('call mysql.rds_start_replication')
        
    with conn.cursor(pymysql.cursors.DictCursor) as curDict:      
        #Print Slave Status to Cloudwatch Logs
        curDict.execute('show slave status')
        slave_status = curDict.fetchall()
        logger.info(slave_status)
    
    
    return 'REPLICATION STARTED SUCCESSFULLY'