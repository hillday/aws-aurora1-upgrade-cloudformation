import json
import boto3
import traceback
import logging
import os
import random

logger = logging.getLogger()
logger.setLevel(logging.INFO)
param = boto3.client('ssm')
rds = boto3.client('rds')
stackName = os.environ['STACK_NAME']

def get_SMM_Parameter(paramName):
    try:
        response = param.get_parameter(
            Name=paramName+'-'+stackName,
            WithDecryption=True
        )
        return response
    except:
        print("Could Not Load Param from AWS SSM Parameter Store")
        #traceback.print_exc()



def check_dbParamGroup(dbParamGroup):
    try:
        response = rds.describe_db_parameter_groups(DBParameterGroupName=dbParamGroup)
        return True
    except:
        #traceback.print_exc()
        return False

def make_dbParamGroup_ReadOnly(dbParamGroup):
    #WRITE STH
    try:
        response = rds.modify_db_parameter_group(
            DBParameterGroupName=dbParamGroup,
            Parameters=[
                {
                    'ApplyMethod': 'immediate',
                    'ParameterName': 'read_only',
                    'ParameterValue': '1'
                    
                },
            ],
        )
    except:
        traceback.print_exc()

def get_AuoraEngineVersion():
    #Describe Clone Cluster & get its Engine version to assign to the new DB Parameter group to be created
    clone_Name = get_SMM_Parameter('A2UP-DBDestinationCluster').get('Parameter').get('Value')
    rds_Clone_Response = rds.describe_db_clusters(
        DBClusterIdentifier=clone_Name
        )
    aurora_Engine = rds_Clone_Response['DBClusters'][0]['Engine']
    if (aurora_Engine == 'aurora-mysql'): 
        return 'aurora-mysql5.7'
    elif (aurora_Engine == 'aurora'):
        return 'aurora5.6'

def create_db_paramGroup(dbParamGroup):
    #Return the namae of the newly created DB parameter group
    try:
        print('**** INSIDE create_db_paramGroup.dbParamGroup= '+dbParamGroup)
        Engine = get_AuoraEngineVersion()
        response = rds.create_db_parameter_group(
            DBParameterGroupName= dbParamGroup,
            DBParameterGroupFamily=Engine,
            Description='The DB Parameter group created for Green Cluster by the Aurora MySQL Blue/Green deployment solution',
            Tags=[
                {
                    'Key': 'Created-By',
                    'Value': 'Aurora2.0Migration'
                },
            ]
        )
        make_dbParamGroup_ReadOnly(dbParamGroup)
        #print(response)
        return dbParamGroup
    except Exception as e:
        logging.error(e)
        if ('InvalidParameterValue' in str(e)):
            logger.info('DB Parameter Group Name provided is invalid, defaulting to aurorablue-green-*******')
            rand = random.randint(1,1544644)
            name = create_db_paramGroup('aurorablue-green-'+str(rand))
            update_SSM_PG(name , 'A2UP-DBParameterGroupName')
        #else:
            #return ''


def update_SSM_PG(value, title):
    try:
        print('Storing: '+value+' in '+title)
        response = param.put_parameter(
            Name=title+'-'+stackName,
            Value=value,
            Type = 'String',
            Overwrite = True,
            Tier='Standard',
        )
        #print('res: '+response)
    except Exception as e:
        logger.error(e)

def get_blueCluster_db_PG():
    blue_cluster = get_SMM_Parameter('A2UP-DBSourceCluster').get('Parameter').get('Value')
    #Load blue cluster details
    blue_cluster_details = rds.describe_db_clusters(
        DBClusterIdentifier=blue_cluster
        )
    db_instances = blue_cluster_details['DBClusters'][0].get('DBClusterMembers')
    #Loop over blue cluster instances to identify Writer
    writer_instance_ID = ''
    blue_cluster_db_ParamGroup = ''
    if db_instances:
        for db in db_instances:
            if db.get('IsClusterWriter'):
                writer_instance_ID = db.get('DBInstanceIdentifier')
    if writer_instance_ID:
        rds_response = rds.describe_db_instances(
            DBInstanceIdentifier=writer_instance_ID
            )
        if rds_response:
            blue_cluster_db_ParamGroup = rds_response['DBInstances'][0].get('DBParameterGroups')[0].get('DBParameterGroupName')
            print('Blue cluster Writer node uses: '+blue_cluster_db_ParamGroup)
            return blue_cluster_db_ParamGroup
    

def lambda_handler(event, context):
    #Create the DB Cluster Parameter Group & DB Parameter Group
    
    #Load the cluster & parameter group names from SSM
    #clustePG = get_SMM_Parameter('A2UP-DBClusterParameterGroupName').get('Parameter').get('Value')
    databasePG = get_SMM_Parameter('A2UP-DBParameterGroupName').get('Parameter').get('Value')
    blue_cluster_db_ParamGroup = get_blueCluster_db_PG()
    
    print('DB Param Group parameter Input: '+databasePG+'\n')
    
    #DB Instance Parameter group
    if (check_dbParamGroup(databasePG)):#DB Instance Parameter group exists
        if (databasePG != 'default.aurora-mysql5.7' and databasePG != 'default.aurora5.6'):
            #Check if the DB parameter group name entered is used by the Source cluster and if so create a new one.
            if (blue_cluster_db_ParamGroup == databasePG):
                rand = random.randint(1,1544644)
                update_SSM_PG(create_db_paramGroup('bluegreen-'+str(rand)), 'A2UP-DBParameterGroupName')
            else:
                make_dbParamGroup_ReadOnly(databasePG)
                update_SSM_PG(databasePG, 'A2UP-DBParameterGroupName')
        else:#User entered the name of a default parameter group
            print('Customer entered the default param group, calling create_db_paramGroup with aurora-bluegreen-*******')
            rand = random.randint(1,1544644)
            update_SSM_PG(create_db_paramGroup('aurorablue-green-'+str(rand)), 'A2UP-DBParameterGroupName')
    else: #Customer either 1)An Incorrect DB Parameter Group Name, 2)Customer left the DBParameterGroup empty. In both cases use the default.aurora-mysql5.7 default DB Parameter Group
        if not databasePG.strip():
            print('Customer enterd an Empty Parameter Group Name, calling create db paramgroup with aurorablue-green')
            rand = random.randint(1,1544644)
            update_SSM_PG(create_db_paramGroup('aurorablue-green-'+str(rand)), 'A2UP-DBParameterGroupName')
        else:
            print('Customer entered a Name for a Parameter group but it does NOT exist, creating a param group')
            name = create_db_paramGroup(databasePG)
            update_SSM_PG(name , 'A2UP-DBParameterGroupName')
          
            
    print('Value in SSM: '+get_SMM_Parameter('A2UP-DBParameterGroupName').get('Parameter').get('Value'))
