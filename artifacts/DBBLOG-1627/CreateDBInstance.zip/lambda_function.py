import json
import boto3
import traceback
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)
param = boto3.client('ssm')
rds = boto3.client('rds')
incoming_Event_Restored_Cluster_ID = ''
stackName = os.environ['STACK_NAME']

def get_SMM_Parameter(paramName):
    try:
        response = param.get_parameter(
            Name=paramName+'-'+stackName,
            WithDecryption=True
        )
        return response
    except:
        print("Could Not Load Param from AWS SSM Parameter Store")
        #traceback.print_exc()
    
def match_incoming_event_create_to_ParameterStore(ssm_destCluster_id,event):
    #incoming_Event_Restored_Cluster_ID = event['detail']['SourceIdentifier']
    print('match function, incoming_Event_Restored_Cluster_ID: '+incoming_Event_Restored_Cluster_ID)
    print('match function: ssm_destCluster_id: '+ssm_destCluster_id)
    
    
    if (ssm_destCluster_id.strip().lower() == incoming_Event_Restored_Cluster_ID.strip().lower()):
        if (event['detail']['SourceType'] == 'CLUSTER' and event['detail']['Message'] == 'DB cluster created'):
            print('Match Function: CONDITION TRUE')
            return True
    else:
        return False
        
def get_SSM_Paramters():
    try:
        parameters = param.get_parameters(
            Names=[
                'A2UP-DBSourceCluster','A2UP-DBDestinationCluster','A2UP-Aurora20Version','A2UP-CreationMode',
                'A2UP-DBClusterVPC','A2UP-VPCSecurityGroups','A2UP-KmsKeyId','A2UP-DBClusterParameterGroupName'
                ],
            WithDecryption=True
        )
        
        return parameters
    except:
        print("Could Not Load SSM Parameters from AWS SSM Parameter Store")
        #traceback.print_exc()

def check_dbParamGroup(dbParamGroup):
    try:
        response = rds.describe_db_parameter_groups(DBParameterGroupName='dbParamGroup')
        return True
    except:
        #traceback.print_exc()
        return False

def make_dbParamGroup_ReadOnly(dbParamGroup):
    #WRITE STH
    try:
        response = rds.modify_db_parameter_group(
            DBParameterGroupName=dbParamGroup,
            Parameters=[
                {
                    'ApplyMethod': 'immediate',
                    'ParameterName': 'read_only',
                    'ParameterValue': '1'
                    
                },
            ],
        )
    except:
        traceback.print_exc()

def create_db_paramGroup(dbParamGroup):
    #Return the namae of the newly created DB parameter group
    try:
        print('**** INSIDE create_db_paramGroup.dbParamGroup= '+dbParamGroup)
        response = rds.create_db_parameter_group(
            DBParameterGroupName= dbParamGroup,
            DBParameterGroupFamily='aurora-mysql5.7',
            Description='The DB Parameter group created for Green Cluster using the A2UPgrader Solution',
            Tags=[
                {
                    'Key': 'Created-By',
                    'Value': 'Aurora2.0Migration'
                },
            ]
        )
        make_dbParamGroup_ReadOnly(dbParamGroup)
        return dbParamGroup
    except Exception as e:
        logging.error(e)
        return ''


def create_DB_Instances():
    #Load Original DB Cluster info
    sourceCluster = get_SMM_Parameter('A2UP-DBSourceCluster').get('Parameter').get('Value')
    #Load Blue Cluster configs
    rds_response = rds.describe_db_clusters(
        DBClusterIdentifier=sourceCluster
        )
    source_cluster_configs = rds_response['DBClusters'][0]
    
    #Load Creation Mode
    #creation_Mode = get_SMM_Parameter('A2UP-CreationMode').get('Parameter').get('Value')
    
    #Load List of DB Cluster Members
    db_instances = source_cluster_configs.get('DBClusterMembers')
    
    writer_instance = {}
    reader_instances = []
    if db_instances:
        for db in db_instances:
            if db.get('IsClusterWriter'):
                writer_instance = db
            else:
                reader_instances.append(db)
    
    DBWriter_identifier = get_SMM_Parameter('A2UP-WriterNode').get('Parameter').get('Value')
    #First create the Writer node
    print('Calling create_db with: '+DBWriter_identifier)
    create_db(writer_instance, DBWriter_identifier)
    
    # #If Blue Cluster has Read Replicas
    # replica_Count = int(get_SMM_Parameter('A2UP-ReadReplicaCount').get('Parameter').get('Value'))
    # if (len(reader_instances)>0):
    #     if (creation_Mode == 'Minimal Resources (Recommended)'):
    #         #Create one Reader with similar configs to the first Reader in the Blue Cluster
    #         DBReader_identifier = get_SMM_Parameter('A2UP-ReadReplica1').get('Parameter').get('Value')
    #         create_db(reader_instances[0], DBReader_identifier)
    #     else:
    #         count =1
    #         while (count<=replica_Count):
    #             if (count <= len(reader_instances)):
    #                 param_name = 'A2UP-ReadReplica'+str(count)
    #                 DBReader_identifier = get_SMM_Parameter(param_name).get('Parameter').get('Value')
    #                 create_db(reader_instances[count-1], DBReader_identifier)
    #             else:
    #                 #More Read replicas requested than actual number of Read Replicas on Blue Cluster
    #                 param_name = 'A2UP-ReadReplica'+str(count)
    #                 DBReader_identifier = get_SMM_Parameter(param_name).get('Parameter').get('Value')
    #                 #Since More Read Replicas are requested than the number of current Replicas on the Blue cluster, all additional instances will be created with the config of the first reader
    #                 create_db(reader_instances[0],DBReader_identifier)
    #             count +=1
    # else:
    #     #Blue Cluster has No Read Replicas
    #     if (creation_Mode == 'Minimal Resources (Recommended)'):
    #         #Create one Reader with similar configs to the writer of the Blue Cluster
    #         DBReader_identifier = get_SMM_Parameter('A2UP-ReadReplica1').get('Parameter').get('Value')
    #         create_db(writer_instance, DBReader_identifier)
    #     else:
    #         count =1
    #         while (count <= replica_Count):
    #             param_name = 'A2UP-ReadReplica'+str(count)
    #             DBReader_identifier = get_SMM_Parameter(param_name).get('Parameter').get('Value')
    #             create_db(writer_instance,DBReader_identifier)
    #             count +=1
    
    
def create_db(db, dbinstance_Identifier):
    #Describe DB Instance
    sourceDB = db.get('DBInstanceIdentifier')
    rds_response = rds.describe_db_instances(
        DBInstanceIdentifier=sourceDB
        )
        
    if rds_response:
        source_Instance_configs = rds_response['DBInstances'][0]
    
    # #Load writer/reader instance identifiers
    # if (mode == 'WRITER'):
    #     writer_identifier = get_SMM_Parameter('A2UP-WRITER_INSTANCE').get('Value')
    # elif (mode == 'READER')
    
    #Define kwargs for restore_db_cluster_from_snapshot
    kwargs = {}
    kwargs['DBInstanceIdentifier'] = dbinstance_Identifier
    kwargs['DBClusterIdentifier'] = incoming_Event_Restored_Cluster_ID
    #if ('DBName' in source_Instance_configs): kwargs['DBName'] = source_Instance_configs['DBName']
    if ('DBInstanceClass' in source_Instance_configs): kwargs['DBInstanceClass'] =  source_Instance_configs['DBInstanceClass']
    
    #The Engine must match the Engine defined in the Clone Cluster. Will describe Clone Cluster & get its Engine version and assign it to this instance being created.
    clone_Name = get_SMM_Parameter('A2UP-DBDestinationCluster').get('Parameter').get('Value')
    rds_Clone_Response = rds.describe_db_clusters(
        DBClusterIdentifier=clone_Name
        )
    clone_Cluster_Engine = rds_Clone_Response['DBClusters'][0]['Engine']
    kwargs['Engine'] = clone_Cluster_Engine
    #DBSecurityGroups are part of the EC2-Classic
    if ('MultiAZ' in source_Instance_configs):
        if (not source_Instance_configs.get('MultiAZ')):
            kwargs['AvailabilityZone'] = source_Instance_configs['AvailabilityZone']
    if ('DBSubnetGroup' in source_Instance_configs):
        kwargs['DBSubnetGroupName'] = source_Instance_configs.get('DBSubnetGroup').get('DBSubnetGroupName')
    if ('PreferredMaintenanceWindow' in source_Instance_configs): kwargs['PreferredMaintenanceWindow'] = source_Instance_configs.get('PreferredMaintenanceWindow')
    
    # dbParamGroup = get_SMM_Parameter('A2UP-DBParameterGroupName').get('Parameter').get('Value')
    if (clone_Cluster_Engine == "aurora"):
        kwargs['DBParameterGroupName'] = 'default.aurora5.6'
    if (clone_Cluster_Engine == "aurora-mysql"):
        kwargs['DBParameterGroupName'] = 'default.aurora-mysql5.7'
    # kwargs['DBParameterGroupName'] = dbParamGroup
    
    
    if ('AutoMinorVersionUpgrade' in source_Instance_configs): kwargs['AutoMinorVersionUpgrade'] = source_Instance_configs.get('AutoMinorVersionUpgrade')
    if ('LicenseModel' in source_Instance_configs): kwargs['LicenseModel'] = source_Instance_configs.get('LicenseModel')
    if ('PubliclyAccessible' in source_Instance_configs): kwargs['PubliclyAccessible'] =  source_Instance_configs.get('PubliclyAccessible')
    if ('TagList' in source_Instance_configs): kwargs['Tags'] = source_Instance_configs.get('TagList')
    if ('MonitoringInterval' in source_Instance_configs):
        kwargs['MonitoringInterval'] = source_Instance_configs.get('MonitoringInterval')
        if ((source_Instance_configs.get('MonitoringInterval') > 0) and ('MonitoringRoleArn' in source_Instance_configs)):
            kwargs['MonitoringRoleArn'] = source_Instance_configs.get('MonitoringRoleArn')
    
    if ('PromotionTier' in source_Instance_configs): kwargs['PromotionTier'] = source_Instance_configs.get('PromotionTier')
    if ('PerformanceInsightsEnabled' in source_Instance_configs): kwargs['EnablePerformanceInsights'] = source_Instance_configs.get('PerformanceInsightsEnabled')
    if ('PerformanceInsightsKMSKeyId' in source_Instance_configs): kwargs['PerformanceInsightsKMSKeyId'] = source_Instance_configs.get('PerformanceInsightsKMSKeyId')
    if ('PerformanceInsightsRetentionPeriod' in source_Instance_configs): kwargs['PerformanceInsightsRetentionPeriod'] = source_Instance_configs.get('PerformanceInsightsRetentionPeriod')
    
    #Create the Instance
    new_DBInstance = rds.create_db_instance(**kwargs)
    print("************* Restored Cluster:")
    print(new_DBInstance)
    print('Creating Instance: '+dbinstance_Identifier)
        
        
    
        
    
    
    
    
    

def lambda_handler(event, context):
    parameter = get_SMM_Parameter('A2UP-DBDestinationCluster')
    ssm_destCluster_id = parameter['Parameter']['Value']
    global incoming_Event_Restored_Cluster_ID 
    incoming_Event_Restored_Cluster_ID = event['detail']['SourceIdentifier']
    print('************* EVENT:')
    print(event)
    
    if (match_incoming_event_create_to_ParameterStore(ssm_destCluster_id,event)):
        print("OKAY CAN CREATE DB INSTANCE RESTORE NOW")
        #1. Create Only Writer Node
        #2. Load Original DB Cluster info
        #3. Pull out DBClusterMembers list
        #4. check the IsClusterWriter to start with the writerInstance and call describe_db_instances to get its full details.
        #5. call create-db-instances to create the writer first
        create_DB_Instances()