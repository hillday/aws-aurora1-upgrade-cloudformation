import json
import boto3
import traceback
import os

rds = boto3.client('rds')
param = boto3.client('ssm')
stackName = os.environ['STACK_NAME']

def get_SMM_Parameter(paramName):
    print('Trying to load SSM param')
    try:
        print('Trying to load SSM param gowaaa')
        response = param.get_parameter(
            Name=paramName+'-'+stackName,
            WithDecryption=True
        )
        return response
    except:
        #print("Could Not Load Param from AWS SSM Parameter Store")
        traceback.print_exc()


def get_SSM_Paramters():
    try:
        parameters = param.get_parameters(
            Names=[
                'A2UP-DBSourceCluster-'+stackName,'A2UP-DBDestinationCluster-'+stackName,'A2UP-Aurora20Version-'+stackName,'A2UP-CreationMode-'+stackName,
                'A2UP-DBClusterVPC-'+stackName,'A2UP-VPCSecurityGroups-'+stackName,'A2UP-KmsKeyId-'+stackName,'A2UP-DBClusterParameterGroupName-'+stackName
                ],
            WithDecryption=True
        )
        
        return parameters
    except:
        print("Could Not Load SSM Parameters from AWS SSM Parameter Store")
        traceback.print_exc()

def check_dbClusterParamGroup(dbClusterParamGroup):
    try:
        response = rds.describe_db_cluster_parameter_groups(DBClusterParameterGroupName=dbClusterParamGroup)
        return True
    except:
        traceback.print_exc()
        return False

def create_Clone_Cluster():
    #Get Customer configuration options from SSM Parameter Store
    parameters = get_SSM_Paramters()
    for param in parameters['Parameters']:
        if (param['Name'] == 'A2UP-DBDestinationCluster-'+stackName):
            greenCluster = param.get('Value')
        elif (param['Name'] == 'A2UP-DBSourceCluster-'+stackName):
            blueCluster = param.get('Value')
        elif (param['Name'] == 'A2UP-VPCSecurityGroups-'+stackName):
            securityGroups = param.get('Value').split(",")
        elif (param['Name'] == 'A2UP-DBClusterParameterGroupName-'+stackName):
            dbClusterParamGroup = param.get('Value')
    
    #load source cluster configurations
    rds_response = rds.describe_db_clusters(
        DBClusterIdentifier=blueCluster
        )
    source_cluster_configs = rds_response['DBClusters'][0]
    
    #Define kwargs for restore_db_cluster_to_point_in_time(**kwargs)
    kwargs = {}
    kwargs['SourceDBClusterIdentifier'] = blueCluster
    kwargs['DBClusterIdentifier'] = greenCluster
    kwargs['RestoreType'] = 'copy-on-write'
    kwargs['UseLatestRestorableTime'] = True
    kwargs['VpcSecurityGroupIds'] = securityGroups
    
    #Check the Cluster Parameter Group value from the CFN is valid and use it. Otherwise, the default Cluster Parameter group for the cluster version is used
    # if (check_dbClusterParamGroup(dbClusterParamGroup)):
    #    kwargs['DBClusterParameterGroupName'] = dbClusterParamGroup
    #else:
        #Using default DB cluster PG based on the Aurora MySQL engine version in use
    if (source_cluster_configs.get('Engine') == "aurora"):
        kwargs['DBClusterParameterGroupName'] = 'default.aurora5.6'
    if (source_cluster_configs.get('Engine') == "aurora-mysql"):
        kwargs['DBClusterParameterGroupName'] = 'default.aurora-mysql5.7'
    
    if ('DBSubnetGroup' in source_cluster_configs): kwargs['DBSubnetGroupName'] = source_cluster_configs.get('DBSubnetGroup') # Taking the exact same SubnetGroup of the original Cluster
    if ('Port' in source_cluster_configs): kwargs['Port'] = source_cluster_configs.get('Port')
    if ('DBClusterOptionGroupMemberships' in source_cluster_configs): kwargs['OptionGroupName'] = source_cluster_configs.get['DBClusterOptionGroupMemberships'][0]['DBClusterOptionGroupName']
    if ('TagList' in source_cluster_configs): kwargs['Tags'] = source_cluster_configs.get('TagList')
    if ('BacktrackWindow' in source_cluster_configs): kwargs['BacktrackWindow'] = source_cluster_configs.get('BacktrackWindow')
    if ('IAMDatabaseAuthenticationEnabled' in source_cluster_configs): kwargs['EnableIAMDatabaseAuthentication'] = source_cluster_configs.get('IAMDatabaseAuthenticationEnabled')
    if ('EnabledCloudwatchLogsExports' in source_cluster_configs): kwargs['EnableCloudwatchLogsExports'] = source_cluster_configs.get('EnabledCloudwatchLogsExports')
    if ('DeletionProtection' in source_cluster_configs): kwargs['DeletionProtection'] = source_cluster_configs.get('DeletionProtection')
    if ('DomainMemberships' in source_cluster_configs and not (not source_cluster_configs['DomainMemberships']) ): 
        kwargs['Domain'] = source_cluster_configs['DomainMemberships'][0]['Domain']
        kwargs['DomainIAMRoleName'] = source_cluster_configs['DomainMemberships'][0]['IAMRoleName']
    

    #******************************************************************************************************************************#
    
    # kwargs = {}
    
    # if ('AvailabilityZones' in source_cluster_configs): kwargs['AvailabilityZones'] = source_cluster_configs['AvailabilityZones']
    # kwargs['SnapshotIdentifier'] = get_snapshotID_paramStore()
    # kwargs['Engine'] = 'aurora-mysql'
    # kwargs['EngineVersion'] = engineVersion.rstrip(',')
    # if ('Port' in source_cluster_configs): kwargs['Port'] = source_cluster_configs['Port']
    # if ('DBSubnetGroup' in source_cluster_configs): kwargs['DBSubnetGroupName'] = source_cluster_configs['DBSubnetGroup'] # Taking the exact same SubnetGroup of the original Cluster
    # if ('DatabaseName' in source_cluster_configs): kwargs['DatabaseName'] = source_cluster_configs['DatabaseName']
    # if ('DBClusterOptionGroupMemberships' in source_cluster_configs): kwargs['OptionGroupName'] = source_cluster_configs['DBClusterOptionGroupMemberships'][0]['DBClusterOptionGroupName']
    # kwargs['VpcSecurityGroupIds'] = securityGroups
    # if ('TagList' in source_cluster_configs): kwargs['Tags'] = source_cluster_configs['TagList']
    # #Will not Specify a KMSKeyId to force use the KMSKeyId that was used to encrypt the DB Cluster Snapshot
    # if ('IAMDatabaseAuthenticationEnabled' in source_cluster_configs): kwargs['EnableIAMDatabaseAuthentication'] = source_cluster_configs['IAMDatabaseAuthenticationEnabled']
    # if ('BacktrackWindow' in source_cluster_configs): kwargs['BacktrackWindow'] = source_cluster_configs['BacktrackWindow']
    # if ('EnabledCloudwatchLogsExports' in source_cluster_configs): kwargs['EnableCloudwatchLogsExports'] = source_cluster_configs['EnabledCloudwatchLogsExports']
    # if ('EngineMode' in source_cluster_configs): kwargs['EngineMode'] = source_cluster_configs['EngineMode']
    # if ('ScalingConfigurationInfo' in source_cluster_configs): kwargs['ScalingConfiguration'] = source_cluster_configs['ScalingConfigurationInfo']
    # if (check_dbClusterParamGroup(dbClusterParamGroup)):
    #     kwargs['DBClusterParameterGroupName'] = dbClusterParamGroup 
    # if ('DeletionProtection' in source_cluster_configs): kwargs['DeletionProtection'] = source_cluster_configs['DeletionProtection']
    # if ('DomainMemberships' in source_cluster_configs and not (not source_cluster_configs['DomainMemberships']) ): 
    #     kwargs['Domain'] = source_cluster_configs['DomainMemberships'][0]['Domain']
    #     kwargs['DomainIAMRoleName'] = source_cluster_configs['DomainMemberships'][0]['IAMRoleName']
    
    
    restored_cluster = rds.restore_db_cluster_to_point_in_time(**kwargs)
    print("************* Restored Cluster:")
    print(restored_cluster)


def lambda_handler(event, context):
    #This function does not require an event, it will trigger by the State Machine after Check Solution Prerequisites to start the Clone Cluster Creation
    # source_Cluster = 'blue-source-cluster-writer-cluster'
    # kwargs = {}
    # kwargs['SourceDBClusterIdentifier'] = source_Cluster
    # kwargs['DBClusterIdentifier'] = 'clone-cluster-00'
    # kwargs['RestoreType'] = 'copy-on-write'
    # kwargs['UseLatestRestorableTime'] = True
    # #Get the List of Security groups from Cloudformation Parameter Store
    # securityGroups = get_SMM_Parameter('A2UP-VPCSecurityGroups').get('Parameter').get('Value').split(',')
    # print(securityGroups)
    # kwargs['VpcSecurityGroupIds'] = securityGroups
    # #Specifying a SubnetGroup name is the only way to influence the restore_db_cluster_to_point_in_time to create the Clone cluster in a different VPC.
    # kwargs['DBSubnetGroupName'] = 'aurorabluegreenvpc-db-subnet'
    
    #Call create_Clone_Cluster()
    create_Clone_Cluster()
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
