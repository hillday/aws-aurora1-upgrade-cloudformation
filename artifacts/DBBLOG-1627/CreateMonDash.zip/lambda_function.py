import json
import boto3
import traceback
import os

region = os.environ['AWS_REGION']
param = boto3.client('ssm')
cw = boto3.client('cloudwatch')
stackName = os.environ['STACK_NAME']

def get_SMM_Parameter(paramName):
    print('Trying to load SSM param')
    try:
        print('Trying to load SSM param gowaaa')
        response = param.get_parameter(
            Name=paramName+'-'+stackName,
            WithDecryption=True
        )
        return response
    except:
        #print("Could Not Load Param from AWS SSM Parameter Store")
        traceback.print_exc()

def lambda_handler(event, context):
    #No incoming event required, this function will be triggerd by the ENABLE_REPLICATION_ON_DESTINATION_CLUSTER
    
    #Load the Green Cluster Writer Node Name
    writer_Node = get_SMM_Parameter('A2UP-WriterNode').get('Parameter').get('Value')
    
    dashboard_Body = {
        "start": "-PT6H",
        "periodOverride": "inherit",
        "widgets": [
            {
                "type": "text",
                "x": 0,
                "y": 0,
                "width": 12,
                "height": 4,
                "properties": {
                    "markdown": "\n## Replication Lag between Green & Blue Cluster\n**This Dashboard was automatically created by the Aurora In-place upgrade solution**\n ```\nThe AuroraBinlogReplicaLag metric shows the amount of time a replica DB cluster running on Aurora with MySQL compatibility lags behind the source DB cluster.\n\nThis metric reports the value of the Seconds_Behind_Master field of the MySQL SHOW SLAVE STATUS command on the Writer Node of the Green Cluster.\n ```\n"
                }
            },
            {
                "type": "metric",
                "x": 0,
                "y": 4,
                "width": 12,
                "height": 6,
                "properties": {
                    "metrics": [
                        [ "AWS/RDS", "AuroraBinlogReplicaLag", "DBInstanceIdentifier", writer_Node ]
                    ],
                    "period": 300,
                    "stat": "Average",
                    "region": region,
                    "title": "Seconds Behind Master - Aurora Binlog Replica Lag",
                    "liveData": True,
                    "legend": {
                        "position": "right"
                    }
                }
            }
        ]
    }
    
    json_obj = json.dumps(dashboard_Body)

    # Create the CW Dashboard
    dashboard_Name = 'Aurora-Binlog-Replication-Lag-'+region+'-'+writer_Node
    response = cw.put_dashboard(
        DashboardName= dashboard_Name,
        DashboardBody=json_obj
    )
    
    return 'CloudWatch Dashboard Created Successfully'
