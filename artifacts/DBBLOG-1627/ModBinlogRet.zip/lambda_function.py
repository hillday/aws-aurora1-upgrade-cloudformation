import json
import logging
import pymysql
import boto3
import traceback

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    logger.info(event)
    
    ENDPOINT=event.get('blue_cluster_endpoint')
    PORT="3306"
    mysql_username = event.get('mysql_master_user').get('username')
    mysql_password = event.get('mysql_master_user').get('password')
    replication_username = event.get('mysql_replication_user').get('username')
    replication_password = event.get('mysql_replication_user').get('password')
    retention_Period = event.get('binlog_retention_period')
    clusterId = event.get('clusterId')
    
    try:
        print('Trying to connect to MySQL......')
        logger.info('Connecting to '+ENDPOINT)
        conn = pymysql.connect(ENDPOINT, user=mysql_username, passwd=mysql_password, connect_timeout=5, autocommit = True)
        cur = conn.cursor()
        
        #Modify Binlog Retention Period
        logger.info('Modifying The Binary log files retention period to '+retention_Period)
        modify_retention_period_command = 'call mysql.rds_set_configuration(\'binlog retention hours\','+retention_Period+');' 
        cur.execute(modify_retention_period_command)
        
        #Create Replication User
        logger.info('Creating MySQL Replication User')
        create_replication_user_command = 'CREATE USER \''+replication_username+'\'@\'%\' IDENTIFIED BY \''+replication_password+'\';'
        grant_privilige_command = 'GRANT REPLICATION SLAVE ON *.* TO \''+replication_username+'\'@\'%\';'
        cur.execute(create_replication_user_command)
        cur.execute(grant_privilige_command)
        
    except pymysql.MySQLError as e:
        print('Could not connect to MySQL')
        logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
        logger.error(e)
        traceback.print_exc()
    
    #Return the clusterId for the next Lambda function(SNAPSHOT_SOURCE_CLUSTER) to consume through the State Machine
    return {"clusterId": clusterId}
