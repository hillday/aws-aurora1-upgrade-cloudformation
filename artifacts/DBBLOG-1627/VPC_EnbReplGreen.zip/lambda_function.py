import json
import boto3
import logging
import ast
import os

lambda_client = boto3.client('lambda')
param = boto3.client('ssm')
rds = boto3.client('rds')
secretsMan = client = boto3.client('secretsmanager')
stackName = os.environ['STACK_NAME']

#global variables
restored_Instance_Name = ''
binlog_File = ''
binlog_Position =  ''
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_SMM_Parameter(paramName):
    print('Trying to load SSM param')
    try:
        print('Trying to load SSM param gowaaa')
        response = param.get_parameter(
            Name=paramName+'-'+stackName,
            WithDecryption=True
        )
        return response
    except:
        #print("Could Not Load Param from AWS SSM Parameter Store")
        traceback.print_exc()
        
def get_secret(secret_name):
    try:
        get_secret_value_response = secretsMan.get_secret_value(
            SecretId=secret_name+'-'+stackName
        )
        return get_secret_value_response
    except:
        print("Could not load a Secret from Secrets Manager, See Exception below")
        traceback.print_exc()

def check_incoming_Event(event):
    #Load the Customer input Writer Name
    writer_Node_Name = get_SMM_Parameter('A2UP-WriterNode').get('Parameter').get('Value')
    global restored_Instance_Name
    if (restored_Instance_Name.strip().lower() == writer_Node_Name.strip().lower()):
        if (event['detail']['SourceType'] == 'DB_INSTANCE' and 'Binlog position from crash recovery' in event['detail']['Message']):
            message = event['detail']['Message']
            global binlog_File, binlog_Position
            binlog_File = message.split('is ')[1].split(' ')[0]
            binlog_Position =  message.split('is ')[1].split(' ')[1]
            print('Binlog File: '+binlog_File)
            print('Binlog Position: '+binlog_Position)
            return True
        else:
            return False
    else:
        return False


def lambda_handler(event, context):
    #This Lambda function acts as a VPC proxy Lambda function for the ENABLE_REPLICATION_ON_DESTINATION_CLUSTER Lambda which runs in a VPC.
    #This Proxy Lambda will do the following:
    # 1. match the incoming Binlog file position event to the writer instance
    # 2. Call RDS describe_isntance to get the Writer Node endpoint
    # 3. Load the MySQL Username and Password to use to connect to the Aurora Green Cluster
    # 4. Load the Blue Cluster Writer/Cluster Endpoint
    
    #Print incoming Event to CW Logs
    logger.info(event)
    
    #Match incoming Binlog event
    global restored_Instance_Name
    restored_Instance_Name = event.get('detail').get('SourceIdentifier')
    if (restored_Instance_Name):
        if check_incoming_Event(event):
            print('Check Passed for Binlog event')
            #Call RDS Describe Instance to get the Writer endpoint
            res = rds.describe_db_instances(
                DBInstanceIdentifier=restored_Instance_Name
                )
            print(res['DBInstances'][0]['Endpoint'])
            endpoint_Address = res.get('DBInstances')[0].get('Endpoint').get('Address')
            endpoint_Port = res.get('DBInstances')[0].get('Endpoint').get('Port')
            
            #Load MySQL Username & Replication User from Secrets Manager
            mysql_master_user = ast.literal_eval(get_secret('A2UP-MySQLMasterUser').get('SecretString'))
            mysql_replication_user = ast.literal_eval(get_secret('A2UP-MySQLReplicationUser').get('SecretString'))
            
            #Load the Blue Cluster Writer/Cluster Endpoint
            blue_Cluster = get_SMM_Parameter('A2UP-DBSourceCluster').get('Parameter').get('Value')
            response_db_cluster = rds.describe_db_clusters(
                DBClusterIdentifier=blue_Cluster
                )
            blue_Cluster_Writer_Endpoint = response_db_cluster.get('DBClusters')[0].get('Endpoint')
            print('blue_Cluster_Writer_Endpoint:'+blue_Cluster_Writer_Endpoint)
            
            #Invoke the ENABLE_REPLICATION_ON_DESTINATION_CLUSTER Lambda function with the payload
             # TODO implement
            data = {
                "writer_Instance_Name": restored_Instance_Name,
                "writer_Endpoint_Address": endpoint_Address,
                "writer_Endpoint_Port": endpoint_Port,
                "mysql_master_user": mysql_master_user,
                "mysql_replication_user": mysql_replication_user,
                "binlog_File": binlog_File,
                "binlog_Position": binlog_Position,
                "blue_Cluster_Writer_Endpoint": blue_Cluster_Writer_Endpoint
            }
            payload_event = json.dumps(data)
            response = lambda_client.invoke(
                FunctionName='EnbReplGreen-'+stackName,
                InvocationType='RequestResponse',
                LogType='Tail',
                #ClientContext='payload_event',
                Payload=payload_event
                )
            print (response)
            
            #Trigger the function to Create the CW Dashboard for Seconds Behind Master Metric
            response_CW = lambda_client.invoke(
                FunctionName='CreateMonDash-'+stackName,
                InvocationType='RequestResponse',
                LogType='Tail',
                Payload= payload_event
                )
            print(response_CW)
            
            return {
                'statusCode': 200,
                'body': json.dumps('Ay Kalam')
            }
            
            
            
            
