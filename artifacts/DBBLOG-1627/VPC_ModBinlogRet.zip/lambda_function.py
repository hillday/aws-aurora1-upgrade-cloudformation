import json
import boto3
import logging
import traceback
import pprint
import ast
import os


lambda_client = boto3.client('lambda')
param = boto3.client('ssm')
rds = boto3.client('rds')
secretsMan = client = boto3.client('secretsmanager')
stackName = os.environ['STACK_NAME']

#global variables
restored_Instance_Name = ''
binlog_File = ''
binlog_Position =  ''
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_SMM_Parameter(paramName):
    try:
        response = param.get_parameter(
            Name=paramName+'-'+stackName,
            WithDecryption=True
        )
        return response
    except:
        #print("Could Not Load Param from AWS SSM Parameter Store")
        traceback.print_exc()
        

def get_secret(secret_name):
    try:
        get_secret_value_response = secretsMan.get_secret_value(
            SecretId=secret_name+'-'+stackName
        )
        return get_secret_value_response
    except:
        print("Could not load a Secret from Secrets Manager, See Exception below")
        traceback.print_exc()    

def lambda_handler(event, context):
   #Print incoming Event to CW Logs
   logger.info(event)
   
   #Load the Blue Cluster Writer/Cluster Endpoint
   blue_Cluster_ID = get_SMM_Parameter('A2UP-DBSourceCluster').get('Parameter').get('Value')
   try:
       response_db_cluster = rds.describe_db_clusters(DBClusterIdentifier=blue_Cluster_ID)
   except:
       traceback.print_exc()
     
   blue_cluster_endpoint = response_db_cluster.get('DBClusters')[0].get('Endpoint')
   logger.info('BLUE Cluster Endpoint: '+blue_cluster_endpoint)
  
   #Load Binglog Retention Period
   binlog_retention_period = get_SMM_Parameter('A2UP-BinlogRetentionPeriod').get('Parameter').get('Value')
   
   #Load MySQL Master user and Replication user
   mysql_master_user = ast.literal_eval(get_secret('A2UP-MySQLMasterUser').get('SecretString'))
   mysql_replication_user = ast.literal_eval(get_secret('A2UP-MySQLReplicationUser').get('SecretString'))
   
   #Invoke the ENABLE_REPLICATION_ON_DESTINATION_CLUSTER Lambda function with the payload
   data = {
       "blue_cluster_endpoint": blue_cluster_endpoint,
       "mysql_master_user": mysql_master_user,
       "mysql_replication_user": mysql_replication_user,
       "binlog_retention_period": binlog_retention_period,
       "clusterId": blue_Cluster_ID
   }
   payload_event = json.dumps(data)
   #Pause calling of the Modify_BINLOG_RETENTION_PERIOD lambda function and instead pass the payload_event back as a result. The State Machine will forward this to the Modify_BINLOG_RETENTION_PERIOD function.
#   response = lambda_client.invoke(
#       FunctionName='Modify_BINLOG_RETENTION_PERIOD',
#       InvocationType='RequestResponse',
#       LogType='Tail',
#       Payload=payload_event
#       )
#   print (response)
   
   pprint.pprint(blue_Cluster_ID)
   print(mysql_master_user.get('username'))
   print(mysql_replication_user.get('password'))
   
   #return data to State Machine
   return data
   
#   return {
#         'statusCode': 200,
#         'body': json.dumps('Hello from Lambda!')
#     }
